package src;

public class Main{
    public static void main(String[] args) {
        new Frame("Tower Of Hanoi");
    }
}